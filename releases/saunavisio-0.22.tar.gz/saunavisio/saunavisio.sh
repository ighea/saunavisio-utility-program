#!/bin/sh
echo $(pwd)
python GUI.py
